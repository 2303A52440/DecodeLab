"""
EventHub Internship - AI Track
Project 2: Data Classification Using AI
DecodeLabs | Batch 2026

Goal
----
Build a basic classification model using a small dataset (the classic
Iris flower dataset) that can predict a flower's species from four
measured features. This follows the "IPO Framework" from the project
brief:

    INPUT   -> Iris dataset, feature scaling
    PROCESS -> Train/test split, K-Nearest Neighbors (KNN) algorithm
    OUTPUT  -> Confusion matrix, F1 score, classification report

Key Requirements covered
-------------------------
1. Load and understand a dataset
2. Split data into training and testing sets
3. Apply a simple classification algorithm (KNN)
4. Evaluate with a confusion matrix + F1 score (not just raw accuracy,
   per the "Accuracy Mirage" warning in the brief)
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    f1_score,
    accuracy_score,
)

RANDOM_STATE = 42  # fixed seed so results are reproducible


# ---------------------------------------------------------------------------
# STEP 1: INPUT - Load and understand the dataset
# ---------------------------------------------------------------------------
def load_data():
    """Load the Iris dataset and return it as a labeled DataFrame."""
    iris = load_iris()
    df = pd.DataFrame(iris.data, columns=iris.feature_names)
    df["species"] = iris.target
    df["species_name"] = df["species"].map(dict(enumerate(iris.target_names)))
    return df, iris


def explore_data(df):
    """Print a quick summary so we understand the raw material (per the
    'Raw Material: The Iris Benchmark' slide - 150 samples, 3 classes,
    4 dimensions)."""
    print("=" * 60)
    print("STEP 1: DATASET OVERVIEW")
    print("=" * 60)
    print(f"Samples: {len(df)}")
    print(f"Classes: {df['species_name'].nunique()} -> {list(df['species_name'].unique())}")
    print(f"Features (dimensions): {df.shape[1] - 2}")
    print("\nFirst 5 rows:")
    print(df.head())
    print("\nClass balance:")
    print(df["species_name"].value_counts())
    print()


# ---------------------------------------------------------------------------
# STEP 2: PROCESS - Split, scale, and train
# ---------------------------------------------------------------------------
def split_and_scale(df, iris, test_size=0.2):
    """Split into train/test sets (shuffled to remove order bias, per the
    'Structural Integrity: The Split' slide), then apply StandardScaler
    (per the 'Gatekeeper Rule: Scaling' slide - mean=0, variance=1)."""
    X = df[iris.feature_names].values
    y = df["species"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=RANDOM_STATE,
        shuffle=True,
        stratify=y,  # keep class balance equal in train and test sets
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)  # transform only, never re-fit on test data

    print("=" * 60)
    print("STEP 2: TRAIN/TEST SPLIT")
    print("=" * 60)
    print(f"Training samples: {len(X_train)} ({(1 - test_size) * 100:.0f}%)")
    print(f"Testing samples:  {len(X_test)} ({test_size * 100:.0f}%)")
    print()

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler


def find_best_k(X_train, y_train, k_range=range(1, 21, 2)):
    """Tune K using cross-validation on the TRAINING set only (never the
    test set - peeking at test data during tuning is a form of leakage).
    We search only odd K values (avoids voting ties) and pick the
    'elbow': the smallest K, beyond K=1, that gives near-best accuracy,
    since K=1 is flagged in the brief itself as prone to noise and
    overfitting."""
    from sklearn.model_selection import cross_val_score

    mean_scores = []
    for k in k_range:
        model = KNeighborsClassifier(n_neighbors=k)
        scores = cross_val_score(model, X_train, y_train, cv=5, scoring="accuracy")
        mean_scores.append(scores.mean())

    error_rates = [1 - s for s in mean_scores]

    # Prefer the smallest K (>1) within 1% accuracy of the best score,
    # avoiding both K=1 overfitting and unnecessarily large K underfitting.
    best_score = max(mean_scores)
    candidates = [k for k, s in zip(k_range, mean_scores) if k > 1 and s >= best_score - 0.01]
    best_k = min(candidates) if candidates else k_range[int(np.argmax(mean_scores))]

    plt.figure(figsize=(8, 5))
    plt.plot(list(k_range), error_rates, marker="o", linestyle="--", color="#1a5276")
    plt.axvline(best_k, color="orangered", linestyle=":", label=f"Chosen K = {best_k}")
    plt.title("Choosing K: 5-Fold CV Error Rate vs. K Value (training set only)")
    plt.xlabel("K Value")
    plt.ylabel("Cross-Validated Error Rate")
    plt.legend()
    plt.tight_layout()
    plt.savefig("/home/claude/k_tuning.png", dpi=150)
    plt.close()

    print("=" * 60)
    print("STEP 2b: TUNING K (KNeighborsClassifier, 5-fold CV on train set)")
    print("=" * 60)
    print(f"Chosen K: {best_k} (cross-validated accuracy = {mean_scores[list(k_range).index(best_k)]:.4f})")
    print("Saved elbow plot -> k_tuning.png\n")

    return best_k


def train_model(X_train, y_train, k):
    """Instantiate and fit the KNN model (the 3-line scikit-learn
    workflow: instantiate -> fit -> predict)."""
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    return model


# ---------------------------------------------------------------------------
# STEP 3: OUTPUT - Evaluate with confusion matrix + F1 score
# ---------------------------------------------------------------------------
def evaluate_model(model, X_test, y_test, target_names):
    predictions = model.predict(X_test)

    acc = accuracy_score(y_test, predictions)
    f1_macro = f1_score(y_test, predictions, average="macro")
    cm = confusion_matrix(y_test, predictions)

    print("=" * 60)
    print("STEP 3: OUTPUT VALIDATION")
    print("=" * 60)
    print(f"Accuracy:      {acc:.4f}")
    print(f"F1 Score (macro): {f1_macro:.4f}")
    print("\nClassification Report:")
    print(classification_report(y_test, predictions, target_names=target_names))

    # Confusion matrix heatmap
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=target_names, yticklabels=target_names,
    )
    plt.title("Confusion Matrix - Iris Species Classification")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    plt.savefig("/home/claude/confusion_matrix.png", dpi=150)
    plt.close()
    print("Saved confusion matrix plot -> confusion_matrix.png\n")

    return acc, f1_macro, cm


def predict_new_sample(model, scaler, target_names):
    """Demonstrate using the trained model on a brand-new, unseen flower
    measurement - proving the model generalizes, not just memorizes."""
    sample = np.array([[5.8, 2.8, 5.1, 2.4]])  # sepal_len, sepal_wid, petal_len, petal_wid
    sample_scaled = scaler.transform(sample)
    prediction = model.predict(sample_scaled)[0]

    print("=" * 60)
    print("BONUS: PREDICTING A NEW, UNSEEN SAMPLE")
    print("=" * 60)
    print(f"Input measurements: {sample.tolist()[0]}")
    print(f"Predicted species: {target_names[prediction]}\n")


# ---------------------------------------------------------------------------
# MAIN PIPELINE
# ---------------------------------------------------------------------------
def main():
    df, iris = load_data()
    explore_data(df)

    X_train, X_test, y_train, y_test, scaler = split_and_scale(df, iris)
    best_k = find_best_k(X_train, y_train)
    model = train_model(X_train, y_train, best_k)
    evaluate_model(model, X_test, y_test, iris.target_names)
    predict_new_sample(model, scaler, iris.target_names)

    print("=" * 60)
    print("PROJECT 2 COMPLETE - milestone unlocked.")
    print("=" * 60)


if __name__ == "__main__":
    main()
