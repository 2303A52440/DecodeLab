# Project 2: Data Classification Using AI
**DecodeLabs Internship — Batch 2026**

## Goal
Build a basic classification model using a small dataset (Iris) that predicts flower species from four measurements, following the supervised learning pipeline: load data → split → scale → train (KNN) → evaluate.

## Files
- `iris_classification.py` — full pipeline, runs end-to-end with `python3 iris_classification.py`
- `k_tuning.png` — cross-validated error rate across K values, used to choose the best K
- `confusion_matrix.png` — test-set confusion matrix for the final model

## Pipeline (IPO Framework)

**Input**
- Iris dataset (150 samples, 3 balanced classes, 4 features)
- Features standardized with `StandardScaler` (mean=0, variance=1) so no single feature dominates due to scale

**Process**
- 80/20 train/test split, shuffled and stratified to preserve class balance
- K chosen via 5-fold cross-validation **on the training set only** (never touching the test set, to avoid data leakage) — search restricted to odd K values 1–19 to avoid voting ties, and K=1 is deliberately avoided since it tends to overfit to noise
- `KNeighborsClassifier` from scikit-learn: instantiate → `fit()` → `predict()`

**Output**
- Confusion matrix (per-class breakdown of correct/incorrect predictions)
- F1 score (macro-averaged) alongside accuracy, since accuracy alone can be misleading ("Accuracy Mirage") — F1 balances precision and recall
- A demo prediction on one brand-new, unseen flower measurement to show the model generalizes

## Results (this run)
- Chosen K: 3
- Test accuracy: 93.3%
- Macro F1 score: 0.933
- Setosa was classified perfectly; a few Versicolor/Virginica samples were confused with each other, which matches the biology — those two species have more overlapping petal/sepal measurements than Setosa does.

## Requirements
```
pip install scikit-learn pandas matplotlib seaborn
```

## Notes / Possible Extensions
- Try a different algorithm (e.g. `LogisticRegression`, `DecisionTreeClassifier`) and compare F1 scores against KNN
- Test the model against a different `random_state` or a different `test_size` to see how stable the results are
- Try `weights='distance'` in `KNeighborsClassifier` so closer neighbors count more than farther ones
