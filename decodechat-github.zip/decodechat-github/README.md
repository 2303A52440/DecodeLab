# DecodeChat

A single-file, ChatGPT-style AI chatbot built with plain HTML, CSS, and JavaScript.
No backend, no build step, no dependencies — open `index.html` in a browser and chat.

Built as part of the DecodeLabs AI Engineering Internship — Project 1 (Rule-Based
AI Chatbot), extended into a real conversational AI interface.

## Features

- Clean, ChatGPT-style chat UI (message bubbles, avatars, typing indicator)
- Multi-turn conversation memory — the model remembers earlier messages in the session
- Live date/time awareness — the model is told the real current date and time on every request
- Zero setup — a single `index.html` file, no server or install required

## Getting started

1. Clone or download this repo
2. Open `index.html` in any browser
3. Get a free API key at [console.anthropic.com](https://console.anthropic.com)
   (**API Keys → Create Key**)
4. Paste your key into the box at the top of the page
5. Start chatting

## How it works

The app calls the [Anthropic Messages API](https://docs.claude.com/en/api/messages)
directly from the browser using `fetch`. Each request sends the full conversation
history so the model has context, plus a `system` prompt containing the live
date/time.

## Security note

Your API key is entered directly into the page and used only within your browser
tab for the duration of that session — it is never saved to disk, stored in
`localStorage`, or sent anywhere except Anthropic's API. It is cleared when you
close or refresh the tab.

**Do not commit your API key to this repository.** This project intentionally has
no server component, so there is no `.env` file or secret storage involved — the
key always stays local to your browser.

For a production app used by other people, don't ship a key-entry field like this;
instead, route requests through your own backend that holds the key server-side.

## Tech stack

- HTML / CSS / vanilla JavaScript
- [Claude Sonnet](https://docs.claude.com) via the Anthropic API

## License

MIT — see [LICENSE](LICENSE).
